#include "iostream"
using namespace std;
int main() {
  int x, b;
  cin >> x;
  if (x >= 300) {
    cout << 10;
  } else {
    cout << 0;
  }
  return 0;
}